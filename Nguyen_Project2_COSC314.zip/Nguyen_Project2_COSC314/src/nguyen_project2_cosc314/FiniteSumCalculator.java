/**
 * Programmer: Daniel Nguyen
 * Class: COSC314
 * Project #1: Calculating a Finite Sum
 * Due Date: 10-05-2024
 * Class Description: Main class where a finite sum is calculated via 
 * arithmetic mathematical expression in the form of a summation
 */
package nguyen_project2_cosc314;
import java.util.*;

public class FiniteSumCalculator {
	public static void main(String[] args) {
		//Set up the scanner and variables
		Scanner input = new Scanner (System.in);
		String expression = "";
		char variable;
		int initial;
		int end;
		int sum = 0;
		
		//do-while loop to input values. Loops if an invalid expression is entered
		do {
			System.out.print("Expression: ");
			expression = input.nextLine();
			System.out.print("Variable: ");
			variable = input.nextLine().charAt(0);
			System.out.print("Initial Value: ");
			initial = input.nextInt();
			System.out.print("Ending Value: ");
			end = input.nextInt();
			
			//Clear initial and end to avoid loop error
			input.nextLine(); 
			expression = removeSpaces(expression);
		}
		while (!checkExpression(expression, variable));
		
		//For-loop that performs summation calculation from initial to end value
		System.out.print("Sequence: ");
		for (int value = initial; value <= end; value++) {
			int result = solveExpression(expression, variable, value);
			System.out.print(result + ", ");
			sum += result;
		}
		
		//Print the sum
		System.out.println();
		System.out.println("Sum = " + sum);
	}
	
	/**
	 * Checks the expression to see if it is a valid expression
	 * @param expression
	 * @param variable
	 * @return true or false
	 */
	public static boolean checkExpression(String expression, char variable) {
		int varCount = 0;
		int termCount = 0;
		boolean correctVar = false;
		for (int i = 0; i < expression.length(); i++) {
			if (expression.charAt(i) == variable) {
				varCount++;
				termCount++;
				correctVar = true;
			}
			else if (Character.isLetter(expression.charAt(i))) {
				varCount++;
			}
			else if (Character.isDigit(expression.charAt(i))) {
				termCount++;
			}
		}
		
		//Series of if-statements to check if the expression is valid
		if (varCount > 1) {
			System.out.println("More than one variable found. Enter an expression with one variable");
			return false;
		}
		else if (correctVar == false) {
			System.out.println("The entered variable does not match the variable in the expression. Try again");
			return false;
		}
		else if (termCount > 3) {
			System.out.println("Too many terms. Enter an expression with 3 or less terms");
			return false;
		}
		return true;
	}
	
	/**
	 * Solves the expression through parsing
	 * @param expression
	 * @param variable
	 * @param initial
	 * @param end
	 * @return the solved expression
	 */
	public static int solveExpression(String expression, char variable, int value) {
		//Break the expression into tokens
		List<String> tokens = toTokens(expression);
		//index value used to point where to go in the list
		int[] index = {0};
		return parseAddSub(tokens, variable, value, index);
	}
	
	/**
	 * Parses and solves the expression for addition or subtraction
	 * @param expression
	 * @param variable
	 * @param initial
	 * @param end
	 * @return
	 */
	private static int parseAddSub(List<String> tokens, char variable, int value, int[] index) {
		//Calls to Multiplication and Division because higher priority
		int answer = parseMultDiv(tokens, variable, value, index);
		while (index[0] < tokens.size()) {
			String token = tokens.get(index[0]);
			if (token.equals("+") || token.equals("-")) {
				index[0]++;
				//Retrieves the integer value after the operation sign
				int nextVal = parseMultDiv(tokens, variable, value, index);
				answer = token.equals("+") ? answer + nextVal : answer - nextVal;
			}
			else {
				break;
			}
		}
		return answer;
	}
	
	/**
	 * Parses and solves the expression for multiplication or division
	 * @param expression
	 * @param variable
	 * @param initial
	 * @param end
	 * @return
	 */
	private static int parseMultDiv(List<String> tokens, char variable, int value, int[] index) {
		//Calls to Exponents because of higher priority
		int answer = parseExponents(tokens, variable, value, index);
		while (index[0] < tokens.size()) {
			String token = tokens.get(index[0]);
			if (token.equals("*") || token.equals("/")) {
				index[0]++;
				//Retrieves the integer value after the operation sign
				int nextVal = parseExponents(tokens, variable, value, index);
				answer = token.equals("*") ? answer * nextVal : answer / nextVal;
			}
			else {
				break;
			}
		}
		return answer;
	}
	
	/**
	 * Parses and solves the expression for exponents
	 * @param expression
	 * @param variable
	 * @param initial
	 * @param end
	 * @return
	 */
	private static int parseExponents(List<String> tokens, char variable, int value, int[] index) {
		//Calls to parenthesis because of higher priority
		int answer = parseParenthesis(tokens, variable, value, index);
		if (index[0] < tokens.size() && tokens.get(index[0]).equals("^")) {
			index[0]++;
			//Retrieves the integer value after the operation sign
			int exponent = parseParenthesis(tokens, variable, value, index);	
			return (int) Math.pow(answer, exponent);
		}
		return answer;
	}
	
	/**
	 * Parses and solves the expression for parenthesis
	 * @param expression
	 * @param variable
	 * @param initial
	 * @param end
	 * @return
	 */
	private static int parseParenthesis(List<String> tokens, char variable, int value, int[] index) {
		String singleToken = tokens.get(index[0]);
		
		if (singleToken.equals("(")){
			index[0]++;
			int answer = parseAddSub(tokens, variable, value, index);
			//Done to skip closing parenthesis
			index[0]++; 
			return answer;
		}
		else {
			index[0]++;
			return variableVal(singleToken, variable, value);
		}
	}
	
	/**
	 * Assigns the value to the variable
	 * @param expression
	 * @param variable
	 * @param initial
	 * @param end
	 * @return
	 */
	private static int variableVal (String singleToken, char variable, int value) {
		//Try-catch statement in place in the scenario that 
		//The user inputs an operator after another operator
		try {
			return singleToken.equals(String.valueOf(variable)) ? value : Integer.parseInt(singleToken);
		}
		catch (NumberFormatException ex) {
			System.out.println("Do not add an operator after another operator");
			return 0;
		}
	}
	
	/**
	 * Takes the expression and breaks it into tokens
	 * @param expression
	 * @return
	 */
	private static List<String> toTokens(String expression){
		List<String> tokens = new ArrayList<>();
		StringBuilder token = new StringBuilder();
		//Boolean value to detect if the negative symbol is being used for negation
		boolean negation = true;
		
		for (int i = 0; i < expression.length(); i++) {
			char c = expression.charAt(i);
			//Appends the integer or assumes the negative means negation
			if(Character.isDigit(c) || c == '-' && negation) {
				token.append(c);
				negation = false;
			}
			else {
				if (token.length() > 0) {
					tokens.add(token.toString());
					token.setLength(0);
				}
				tokens.add(String.valueOf(c));
				negation = (c == '(' || c == '*' || c == '/' || c == '+' || c == '-' || c == '^');
			}
		}
		if (token.length() > 0) {
			tokens.add(token.toString());
		}
		return tokens;
	}
	
	/**
	 * Receives the string expression and removes spaces
	 * @param expression
	 * @return expression with no spaces
	 */
	private static String removeSpaces(String expression) {
		return expression.replaceAll("\\s+", "");
	}
}
