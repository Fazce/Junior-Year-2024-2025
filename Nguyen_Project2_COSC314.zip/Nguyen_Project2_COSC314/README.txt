README text file for Daniel Nguyen's Finite Sum Calculator Program

This program was written in Java through the Eclipse IDE. It is recommended to run the program in Eclipse for the best results, but any IDE capable of running Java should suffice. 

Program Components:
------------------------
All of the necessary components required to run the program is in one Java class (FiniteSumCalculator.java)
------------------------


How to run:
----------------------
Run FiniteSumCalculator.java
----------------------


Expected Inputs:
-----------------------
When running, the program will prompt the user to enter 4 inputs: expression, the variable, the initial value, and the ending value in that order. The expression is expected to have only a maximum of 3 terms and one variable. If the entered expression contains more than 3 terms, more than one variable, or the input entered when the program asks for the variable is different to the variable in the expression, then a message will appear in the console that tells the user their mistake. Afterward, the user will need to re-enter all 4 inputs correctly. 

If a non integer variable is entered for the initial value and/or the ending value, the program will reach an InputMismatchException and the program will terminate. 
------------------------	


Output Formatting:
------------------------
The output formatting should be similar to the example on Canvas. 

Expression: 
Variable:
Initial Value:
Ending Value:
Sequence:
Sum = 
-----------------------


Arithmetic Symbols:
-----------------------
The arithmetic symbols used in the program are as follows

"+" is Addition
"-" is Subtraction and Negation
"*" is Multiplication
"/" is Division
"^" is Exponents
----------------------


Additional Information:
------------------------
The number of spaces used when entering the expression is irrelevant. The method "removeSpaces" will remove all spaces in the String expression.

If the user accidentally (or purposely) adds a mathematical operation after another operation or parenthesis in their expression (ex: x +* 4), it will cause a NumberFormatException. This exception will be caught in the "variableVal" method where a print statement will be printed in the console, stating the user to not input an operation after another operation in the expression. Due to variableVal being an int method, it expects a return statement even if the exception is reached, so the program will still continue until it reaches the ending value. However, the output will definitely be incorrect.

The only exception to the above is with the "-" operator. The program treats "-" as subtraction and negation. This means that you can apply the "-" symbol before or after any operator in the expression (ex: x * -4 or -4 * x) and the program will run perfectly fine. 