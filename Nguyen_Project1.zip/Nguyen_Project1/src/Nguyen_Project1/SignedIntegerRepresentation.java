/**
 * Programmer: Daniel Nguyen
 * Class: COSC211
 * Project #: 1
 * Due Date: 9-30-24
 * Class Description: Program that prompts the user to input a signed decimal or binary string
 * and outputs the calculated signed magnitude, ones and twos complement, and excess notation
 */
package Nguyen_Project1;
import java.util.*;

public class SignedIntegerRepresentation {

	public static void main(String[] args) {
		Scanner input = new Scanner (System.in);
		System.out.println("Enter 1 to convert a decimal integer, 2 to convert a binary string, or 3 to quit: ");
		int option = input.nextInt(); 
		
		while (option < 3) {
			if (option == 1) {
				System.out.println("Enter a signed decimal integer: ");
				int decimalInt = input.nextInt();
				int bits = calculateTotalBits(decimalInt);
				int notationVal = calculateExcessNotation(decimalInt, bits);
				
				System.out.println("Results: ");
				System.out.println("Signed Magnitude: " + decimalToSignedMagnitude(decimalInt, bits));
				System.out.println("Ones Compliment: " + decimalToOnesCompliment(decimalInt, bits));
				System.out.println("Twos Compliment: " + decimalToTwosCompliment(decimalInt, bits));
				System.out.println("Excess-" + notationVal + ": " + decimalToExcessNotation(decimalInt, notationVal, bits));
			}
			else {
				System.out.println("Enter a binary string: ");
				String binary = input.next();
				int bits = binary.length();
				int notationVal = calculateExcessNotation(binary, bits);
				
				System.out.println("Results: ");
				System.out.println("Signed Magnitude: " + binaryToSignedMagnitude(binary));
				System.out.println("Ones Compliment: " + binaryToOnesCompliment(binary));
				System.out.println("Twos Compliment: " + binaryToTwosCompliment(binary));
				System.out.println("Excess-" + notationVal + ": " + binaryToExcessNotation(binary, notationVal));
			}
			
			System.out.println("Enter 1 to convert a decimal integer, 2 to convert a binary string, or 3 to quit: ");
			option = input.nextInt(); 
		}
		
		System.out.println("Farewell!");
	}
	
	/**
	 * Calculates the number of bits required for the input integer
	 * @param decimalInt
	 * @return the number of bits
	 */
	public static int calculateTotalBits (int decimalInt) {
		int bits = 0;
		if (decimalInt >= 0) {
			bits = (int) (Math.log(decimalInt) / Math.log(2) + 1);
		}
		else {
			bits = (int) (Math.log(Math.abs(decimalInt)) / Math.log(2) + 2);
		}
		return bits;
	}
	
	/**
	 * Calculates the Excess Notation for the decimal integer
	 * @param bits
	 * @return the notation
	 */
	public static int calculateExcessNotation (int decimalInt, int bits) {
		if (decimalInt >= 0) {
			return (int) Math.pow(2, bits);
		}
		else {
			return (int) Math.pow(2, bits - 2);
		}
	}
	
	/**
	 * Calculates the Excess Notation for a binary string
	 * @param bits
	 * @return the notation
	 */
	public static int calculateExcessNotation (String binary, int bits) {
		if (binary.charAt(0) == '0') {
			return (int) Math.pow(2, bits);
		}
		else {
			return (int) Math.pow(2, bits - 2);
		}
	}
	
	/**
	 * Converts the decimal integer into a signed magnitude binary form
	 * @param decimalInt
	 * @return the binary form signed magnitude
	 */
	public static String decimalToSignedMagnitude (int decimalInt, int bits) {
		String binaryMag = Integer.toBinaryString(Math.abs(decimalInt));
		if (decimalInt < 0) {
			binaryMag = "1" + binaryMag;
		}
		else {
			binaryMag = "0" + binaryMag;
		}
		return binaryMag;
	}
	
	/**
	 * Converts a decimal integer into its ones compliment form
	 * @param decimalInt
	 * @param bits
	 * @return the binary form of the ones compliment of the decimal integer
	 */
	public static String decimalToOnesCompliment (int decimalInt, int bits) {
		if (decimalInt >= 0) {
			return decimalToSignedMagnitude(decimalInt, bits);
		}
		else {
			String binaryOnes = decimalToSignedMagnitude(Math.abs(decimalInt), bits);
			return invertBits(binaryOnes);
		}
	}
	
	/**
	 * Converts a decimal integer to its twos compliment form
	 * @param decimalInt
	 * @param bits
	 * @return the binary form of the twos compliment of the decimal integer
	 */
	public static String decimalToTwosCompliment (int decimalInt, int bits){
		if (decimalInt >= 0) {
			return decimalToSignedMagnitude(decimalInt, bits);
		}
		else {
			String binaryOnes = decimalToOnesCompliment(decimalInt, bits);
			return addOne(binaryOnes);
		}
	}
	
	/**
	 * Adds the excess to the decimal and convert it to a binary string
	 * @param decimalInt
	 * @param notationVal
	 * @param bits
	 * @return
	 */
	public static String decimalToExcessNotation (int decimalInt, int notationVal, int bits) {
		int excessVal = 0;
		if (decimalInt >= 0) {
			excessVal = decimalInt + notationVal;
		}
		else {
			excessVal = notationVal;
		}
		return Integer.toBinaryString(excessVal);
	}
	
	/**
	 * Converts a binary string into a decimal signed magnitude
	 * @param binary
	 * @return the decimal signed magnitude
	 */
	public static int binaryToSignedMagnitude (String binary) {
		int checkSign = binary.charAt(0) == '1' ? -1 : 1;
		int magnitude = Integer.parseInt(binary.substring(1), 2);
		return checkSign * magnitude;
	}
	
	/**
	 * Converts a binary string to decimal ones compliment
	 * @param binary
	 * @return the decimal ones compliment
	 */
	public static int binaryToOnesCompliment (String binary) {
		if (binary.charAt(0) == '0') {
			return Integer.parseInt(binary, 2);
		}
		else {
			String invertedBinary = invertBits(binary);
			return -Integer.parseInt(invertedBinary, 2);
		}
	}
	
	/**
	 * Converts a binary string to decimal twos compliment
	 * @param binary
	 * @return the decimal twos compliment
	 */
	public static int binaryToTwosCompliment (String binary) {
		if (binary.charAt(0) == '0') {
			return Integer.parseInt(binary, 2);
		}
		else {
			int minVal = Integer.parseInt(binary, 2);
			int maxVal = (int) Math.pow(2, binary.length());
			return minVal - maxVal;
		}
	}
	
	/**
	 * Adds the excess to the binary and return it in decimal form
	 * @param binary
	 * @param notationVal
	 * @return the decimal integer after adding the excess
	 */
	public static int binaryToExcessNotation (String binary, int notationVal) {
		int excessVal = Integer.parseInt(binary, 2);
		return excessVal - notationVal;
	}
	
	/**
	 * Inverts the binary of a ones compliment negative integer 
	 * @param binary
	 * @return the inverted binary
	 */
	private static String invertBits (String binary) {
		StringBuilder invertedBinary = new StringBuilder();
		for (char bit : binary.toCharArray()) {
			invertedBinary.append(bit == '0' ? '1' : '0');
		}
		return invertedBinary.toString();
	}
	
	/**
	 * Adds 1 to a ones compliment binary in order to get the twos compliment
	 * @param binary
	 * @return the twos compliment
	 */
	private static String addOne (String binary) {
		int num = Integer.parseInt(binary, 2);
		num = num + 1;
		return Integer.toBinaryString(num);
	}
}
