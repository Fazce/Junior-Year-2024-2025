README file for Daniel Nguyen's Signed Integer Representation Program

The program was written in Java through the Eclipse IDE. It is recommended to run the program through Eclipse for the best results, but any IDE that can run Java should still work. 

Program components:
---------------------
All of the contents required for the program to run is contained inside of one class (SignedIntegerRepresentation.java). 


How to run:
-----------------
There is only one class in the file. This is the file that the user will need to run.

When the program runs, it will immediately ask the user to input 1 to enter a decimal input, 2 to enter a binary string, or 3 to exit the program. 

If 1 or 2 are chosen, the program will move to a while loop where the user will be asked to input either a decimal or a binary string. Afterward, the program will run and complete the conversion, and output them shortly after in the console. After the results of the representations are shown, the prompt asking the user to input 1 of 3 options will appear again. Depending on the option chosen, the program will repeat the while loop, or exit it. If the loop ends, a farewell message is displayed before the program terminates. 

Entering any number above 3 when asked to either enter 1, 2, or 3 will simply result in the program ignoring/exiting the while loop and display the farewell message. 

Extra Notes:
------------------
This program should work correctly for any positive integer. However, in regard to negative integers, the excess-notation output will unfortunately be incorrect. I have tried to figure out where the program is performing the math incorrectly, but was unable to solve the issue before the due date.

A similar problem occurs with binary strings. While the signed magnitude, ones compliment, and twos compliment output will be correct when it is either a positive or negative binary string, the excess-notation will always be incorrect. Again, I was unable to solve this before the due date. 