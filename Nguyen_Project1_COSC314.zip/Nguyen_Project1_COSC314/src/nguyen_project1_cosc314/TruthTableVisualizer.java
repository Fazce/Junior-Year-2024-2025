/**
 * Programmer: Daniel Nguyen
 * Class: COSC314
 * Project #: 1 - Comparing Compound Propositions for Logical Equivalency
 * Due Date: 09-27-2024
 * Class Description: Main class where two compound propositions and their truth values
 * are entered by the user then compared. 
 * The output displays the truth table for both propositions and if they are equivalent.
 */

package nguyen_project1_cosc314;
import java.util.*;

public class TruthTableVisualizer {
	public static void main(String[] args) {
		Scanner input = new Scanner (System.in);
		boolean validPropositions = false;
		String firstProposition = "";
		String secondProposition = "";
			
		while (validPropositions == false) {
			//Asks user for to enter propositions
			System.out.println("Enter first proposition: ");
			firstProposition = input.nextLine();
			System.out.println("Enter second proposition: ");
			secondProposition = input.nextLine();
			validPropositions = checkVariables(firstProposition, secondProposition);
			if (validPropositions == false) {
				System.out.println("The proposition(s) is invalid. Try again");
			}
		}
		
		//Obtains a list of the variables in both propositions
		List<Character> variables = receiveVariables(firstProposition);
		
		//Copy the propositions and remove the spaces from both propositions
		String firstPropNoSpace = removeSpaces(firstProposition);
		String secondPropNoSpace = removeSpaces(secondProposition);
		
		List<boolean[]> truthList = createTruthValues(variables.size());
		
		System.out.println(variables + " | [ " + firstProposition + " ] | [ " + secondProposition + " ] ");
		System.out.println("-------------------------------------------------");
		
		//boolean flag that checks if both propositions are equal
		boolean equivalent = true;
		
		//Begin solving and evaluating the two propositions
		for (boolean[] truthVals : truthList) {
			boolean propositionOne = solveProposition(firstPropNoSpace, variables, truthVals);
			boolean propositionTwo = solveProposition(secondPropNoSpace, variables, truthVals);
			
			//checks if the propositions are equal to each other
			if (propositionOne != propositionTwo) {
				equivalent = false;
			}
			
			//prints out the truth values of the variables and the evaluated proposition
			for (boolean truthValue : truthVals) {
				System.out.print(truthValue + " ");
			}
			System.out.print(" | " + propositionOne + " | " + propositionTwo + "\n");
		}
		
		//Print statement that tells if they are equal
		if (equivalent) {
			System.out.println("The propositions are equal");
		}
		else {
			System.out.println("The propositions are not equal");
		}
	}
		
	/**
	 * Checks the amount of variables in the propositions
	 * Sees if both propositions contain the same variables 
	 * @param firstProposition
	 * @param secondProposition
	 */
	public static boolean checkVariables (String firstProposition, String secondProposition) {
		//Character arrays to store the variables in the propositions
		char[] firstVars = new char [3];
		char[] secondVars = new char [3];
		
		//Fill in the character arrays with the variables from the propositions
		fillVarsArrays(firstVars, firstProposition);
		fillVarsArrays(secondVars, secondProposition);
		
		//Sorts the arrays to simplify/make comparison easier
		Arrays.sort(firstVars);
		Arrays.sort(secondVars);
		
		return Arrays.equals(firstVars, secondVars);
	}
		
	/**
	 * Receives a character array and proposition
	 * Fills in the array with lowercase version of variables in the proposition
	 * @param varArray
	 * @param proposition
	 */
	private static void fillVarsArrays (char[] varArray, String proposition) {
		//flag variable that will be used to insert a variable at a location in the array
		int flag = 0;
		//for loop that iterates through the whole string to find the variables
		for (int i = 0; i < proposition.length(); i++) {
			char checkVar = proposition.charAt(i);
			if (Character.isLetter(checkVar)) {
				if (flag >= 3) {
					System.out.println("More than three variables detected. Please restart the program");
					return;
				}
				varArray[flag] = Character.toLowerCase(checkVar);
				flag++;
			}
		}
	}
	
	/**
	 * Retrieves the variables within the proposition and stores them in a list
	 * @param proposition
	 * @return the list of variables
	 */
	public static List<Character> receiveVariables (String proposition){
		//Create a HashSet to store the variables in a Hash
		Set<Character> vars = new HashSet<>();
		
		//for-each loop to iterate over the string turned array
		for (char var : proposition.toCharArray()) {
			if (Character.isLetter(var)) {
				vars.add(var);
			}
		}
		
		//Turn the set into a list and sort the list
		List<Character> varList = new ArrayList<>(vars);
		Collections.sort(varList);
		return varList;
	}
	
	/**
	 * Create all of the possible truth values and combinations for the existing variables
	 * @param varCount
	 * @return the list of all truth values for each variable
	 */
	public static List<boolean[]> createTruthValues (int varCount){
		//row count integer based on the amount of variables in the propositions
		int numRowCount = (int) Math.pow(2, varCount);
		List<boolean[]> truthList = new ArrayList<>();
		
		//Iterates through all of the rows and inserts all possible values and combinations
		for (int i = 0; i < numRowCount; i++) {
			boolean[] row = new boolean[varCount];
			for (int j = 0; j < varCount; j++) {
				//Uses a bitwise operation to determine if the value is true or false
				row[j] = (i & (1 << j)) != 0;
			}
			truthList.add(row);
		}
		
		return truthList;
	}
	
	/**
	 * Solves both of the entered propositions with all possible truth values and combinations
	 * @param proposition, variables, truthVals
	 * @return the evaluations of the propositions
	 */
	public static boolean solveProposition (String proposition, List<Character> variables, boolean[] truthVals) {
		//Takes the string proposition and breaks it into tokens
		List<String> propositionTokens = toTokens(proposition);
		//enter a recursive parse to turn the string tokens into boolean values
		return parseProposition(propositionTokens, variables, truthVals);
	}
	
	/**
	 * Takes the string of the proposition and turns them into tokens
	 * @param proposition
	 * @return the list of propositions as tokens
	 */
	private static List<String> toTokens (String proposition){
		List<String> propositionTokens = new ArrayList<>();
		//Create a token using StringBuilder since StringBuilder can be changed/is mutable
		StringBuilder token = new StringBuilder();
		
		//For-each loop that goes through the entire string when turned into an array
		for (char val : proposition.toCharArray()) {
			//appends a character to the token if is a character/variable
			if (Character.isLetter(val)) {
				token.append(val);
			}
			//if the character is not a variable, add it to the array list
			else {
				if (token.length() > 0) {
					propositionTokens.add(token.toString());
					token.setLength(0);
				}
				//checks for parenthesis, AND, OR, and NOT to insert as tokens
				if (val == '(' || val == ')' || val == '!' || val == '&' || val == '|') {
					propositionTokens.add(String.valueOf(val));
				}
			}
		}
		
		if (token.length() > 0) {
			propositionTokens.add(token.toString());
		}
		
		return propositionTokens;
	}
	
	/**
	 * Parses the proposition, turning a String value to a boolean value
	 * @param tokens
	 * @param variables
	 * @param truthVals
	 * @return the parsed proposition
	 */
	private static boolean parseProposition (List<String> tokens, List<Character> variables, boolean[] truthVals) {
		return parseOR (tokens, variables, truthVals);
	}
	
	/** 
	 * Parses for a potential OR statement. 
	 * @param tokens
	 * @param variables
	 * @param truthVals
	 * @return
	 */
	private static boolean parseOR (List<String> tokens, List<Character> variables, boolean[] truthVals) {
		//Goes to parseAND first because AND occurs first in the order of operations
		boolean result = parseAND (tokens, variables, truthVals);
		while (!tokens.isEmpty() && tokens.get(0).equals("|")) {
			tokens.remove(0);
			result = result || parseAND (tokens, variables, truthVals);
		}
		return result;
	}
	
	/**
	 * Parses for a potential AND statement
	 * @param tokens
	 * @param variables
	 * @param truthVals
	 * @return
	 */
	private static boolean parseAND (List<String> tokens, List<Character> variables, boolean[] truthVals) {
		//Goes to parseNOT because NOT is higher in order of operations
		boolean result = parseNOT (tokens, variables, truthVals);
		while (!tokens.isEmpty() && tokens.get(0).equals("&")) {
			tokens.remove(0);
			result = result && parseNOT (tokens, variables, truthVals);
		}
		return result;
	}
	
	/** 
	 * Parses for a potential NOT in the proposition
	 * @param tokens
	 * @param variables
	 * @param truthVals
	 * @return
	 */
	private static boolean parseNOT (List<String> tokens, List<Character> variables, boolean[] truthVals) {
		if (!tokens.isEmpty() && tokens.get(0).equals("!")) {
			tokens.remove(0);
			return !parseParenthesis(tokens, variables, truthVals);
		}
		return parseParenthesis(tokens, variables, truthVals);
	}
	
	/**
	 * Parses for parenthesis in the proposition
	 * @param tokens
	 * @param variables
	 * @param truthVals
	 * @return
	 */
	private static boolean parseParenthesis (List<String> tokens, List<Character> variables, boolean[] truthVals) {
		//obtain one token as a string, which is either a parenthesis or a variable
		String singleToken = tokens.remove(0);
		
		if (singleToken.equals("(")) {
			boolean result = parseProposition(tokens, variables, truthVals);
			//If reached, this should remove the other closing parenthesis
			tokens.remove(0);
			return result;
		}
		else {
			return variableEval(singleToken, variables, truthVals);
		}
	}
	
	/**
	 * Evaluates the truth value of a variable by finding its index in the Character LIST and boolean array
	 * @param singleToken
	 * @param variables
	 * @param truthVals
	 * @return
	 */
	private static boolean variableEval (String singleToken, List<Character> variables, boolean[] truthVals) {
		int index = variables.indexOf(singleToken.charAt(0));
		return truthVals[index];
	}
	/**
	 * Receives a string proposition and removes any spaces in the string
	 * Makes it easier for the program to read a proposition
	 * @param proposition
	 */
	public static String removeSpaces (String proposition) {
		return proposition.replaceAll("\\s+", "");
	}
}