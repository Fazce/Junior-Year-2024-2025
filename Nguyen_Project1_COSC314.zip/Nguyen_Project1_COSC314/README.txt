Read Me text file for my Logical Equivalency program

How to run and compile my program:
----------------------------------
My program was done through Java in the Eclipse IDE. I would recommend running my program through Eclipse, but other IDEs that can run Java should work.


Expected inputs:
----------------
It is expected that the propositions entered must have a minimum of 2 variables and a maximum of 3 variables, and these variables must be alphabetical letters. Both propositions must also use the same variables. If the propositions entered do not have the same variables, a print statement will say "The proposition(s) is invalid. Try again." and the user will need to re-enter valid propositions

Any alphabetical letter can be used when asked to enter a proposition. The variables can also be Uppercase letters or Lowercase letters. HOWEVER, the variables must be in ALL Uppercase or ALL lowercase. Entering two propositions with a mix of both (i.e Proposition 1 = A & C | B, and Proposition 2 = a | C & b) will cause the program to get an ArrayIndexOutOfBounds Exception due to the program considering the Uppercase and Lowercase characters as different characters.

The program reads the AND connective as &, the OR operation as |, and the NOT operation as !. Parenthesis are the obvious ( and ). 

When entering the input propositions, the proposition can include spaces between the variables and connectives (i.e A | C & B) or can be written without spaces (i.e A|C&B)


How the program works:
-----------------------
The first thing the program does is start a while loop. In this while loop, it asks for the user to enter the first proposition, and then the second as a String. Afterwards, both propositions are sent to the checkVariables method, which checks the amount of variables within each proposition and see if they are the same. In this method, two char arrays are made for each proposition. Then, a call to a void method named fillVarsArrays is called with the method receiving a proposition and a char array as its parameters. 

In the fillVarsArrays method, an int flag value is created, which is used to store a char within the index equal to the flag value. This value is set to 0 at the start. Then, a for-loop starts that iterates through the string proposition. This for-loop every char in the string to see if it is a letter, and if it finds a letter, it enters the letter into the received char array param at the flag value. The flag value is then increased by 1. 

If the flag value is greater than or equal to 3, a print statement will be printed, saying that "More than three variables detected. Please restart the program." and the program will terminate. 

After the fillVarsArrays method completes its job on both propositions, the checkVariables method will sort both char arrays to make comparison easier and return true or false depending on if the char arrays are equal. If not equal, the while-loop continues until checkVariables returns true

Once the program exits the while loop, a List of Characters named variables is created. This list will hold all of the variables. To fill this list, a call to a method named receiveVariables is done. This method has a string as its parameter. In the program, the first proposition is sent to this method, but either propositions works as they both have the same variable if this method is called.

In the receiveVariables method, a HashSet of Characters is created to store each variable in a Hash. Then, a for-each loop iterates through the proposition as a char array and enters any letter into the Set. After the for-each loop completes, an ArrayList of Characters named varList is created using the HashSet. The ArrayList is sorted shortly after and is returned.

Then, a List of Boolean arrays named truthList is created. This value calls to a method named createTruthValues. The method receives the variable count as a parameter and returns a List containing all possible truth values and combinations possible with the total amount of variables. This is done using bitwise operations, which I learned about a few weeks back in COSC 211, but I did have to search up how to implement bitwise operations in programming. Thankfully, I found a source that gave me the basics: https://www.geeksforgeeks.org/bitwise-operators-in-java/

Now for how the program evaluates the proposition. Because the propositions are a String, I had to use parsing in order to turn the Strings into Boolean values, and to do that, I had to first split the Strings into tokens. Once that was done, the program stores the tokens into a list. Then, the list of tokens, the variables in the propositions, and all of the truth values are sent into a series of recursive parsing methods that operate in the proper order of operations. These are then returned to the main method, which outputs them on a table in the console.

During the evaluation process, a flag is used to check if the propositions are equal. This flag will trigger one of two print statements: one that says the propositions are equal or one that states they are not.

The program will display a table that is, admittedly messy, but should be correct. The variables and the propositions are displayed on top with a vertical line and brackets used to make the formatting more easy to read. Many dash lines are also printed to separate them from the truth values below. Below the dash lines, all of the possible truth values and combinations are listed. Unfortunately, the values don't perfectly align with the variables and propositions. 

After the table is printed, a final print statement will declare if the propositions are equal or not.
-----------------------------

None of my program came from an source, but I did use a few sources to learn about functions used in my program such as the bitwise operations, String Tokens, and String Builder.

https://www.geeksforgeeks.org/bitwise-operators-in-java/
https://www.geeksforgeeks.org/stringtokenizer-class-in-java/
https://www.geeksforgeeks.org/stringbuilder-class-in-java-with-examples/