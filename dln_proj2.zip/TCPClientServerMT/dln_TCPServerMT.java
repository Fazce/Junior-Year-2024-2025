//Programmer: COSC 439/522, winter '25
//Multi-threaded Server program
//File name: TCPServerMT.java
//When you run this program, you must give the service port
//number as a command line argument. For example,
//java TCPServerMT 22222


import java.io.*;
import java.net.*;
import java.util.*;
import java.nio.file.*;

public class dln_TCPServerMT
{
 private static ServerSocket servSock;
 public static void main(String[] args)
 {
     System.out.println("Opening port...\n");
    try{

        //Create a server object
         servSock = new ServerSocket(Integer.parseInt(args[0])); 
    }
    catch(IOException e){
         System.out.println("Unable to attach to port!");
        System.exit(1);
    }
    do
    {
       run();
    }while (true);

  }

  private static void run()
  {
    Socket link = null; 

	try
	{
	   //Put the server into a waiting state
	   link = servSock.accept(); //The start of the run loop
	
	  //Print local host name
	   String host = InetAddress.getLocalHost().getHostName();
	   System.out.println("Client has estabished a connection to " + host);
     File chatFile = new File("dln_chat.txt");
     if (!ClientHandler.connections.isEmpty() && !chatFile.exists()) {
      try {
        chatFile.createNewFile();
      }
      catch (IOException noFile){

      }
    }
    
	   //Create a thread to handle this connection
	   ClientHandler handler = new ClientHandler(link);

	   //Start serving this connection
	   handler.start(); 
	}
	catch(IOException e){
	    e.printStackTrace();
	}

  }

}

class ClientHandler extends Thread
{
  private Socket client;
  private Scanner in;
  private PrintWriter out;
  private static PrintWriter chatTextFile;
  private String username = null;
  static FileWriter fWriter = null;
  public static ArrayList<Socket> connections = new ArrayList<>();
  private static Map<Socket, PrintWriter> clientWriters = new HashMap<>();
  private long startTime;
  public ClientHandler(Socket s)
  {
    try{
      if (fWriter == null) {
        fWriter = new FileWriter("dln_chat.txt", true);
      }
      if (chatTextFile == null) {
        chatTextFile = new PrintWriter(fWriter);
      }
    }
    catch (IOException excep) {

    }
     //Set up the socket
     client = s;
     connections.add(s);
     this.startTime = System.currentTimeMillis();
     try
     {
           //Set up input and output streams for socket
           in = new Scanner(client.getInputStream()); 
           out = new PrintWriter(client.getOutputStream(),true); 
           synchronized (clientWriters) {
            clientWriters.put(client, out);
           }
      }
     catch(IOException e){
          e.printStackTrace();
     }
   }

   //Overwrite the method 'run' of the Runnable interface

   //This method is called automatically when a client thread starts.
   public void run()
  {

      //Receive and process the incoming data 
	  int numMessages = 0;

    //Receive username first
    if (in.hasNextLine()) {
       username = in.nextLine();
       System.out.println(username + " has joined");

       synchronized (chatTextFile) {
        chatTextFile.append(username + " has joined\r\n");
        chatTextFile.flush();
       }

       showMessage(username + " has joined", client);
    }

    //Send and receive messages
	  String message = "";
	   while (!message.equals("DONE"))
	   {
        //Skips blank messages
        if (message.trim().isEmpty()) { 
          if (in.hasNextLine()) {
            message = in.nextLine();
          }
          else {
            break;
          }
          continue;
        }

	        System.out.println(message);
          try{
            synchronized(chatTextFile) {
              String chatMessage = username + ": " + message;
              chatTextFile.append(chatMessage + "\r\n");
              chatTextFile.flush();
              showMessage(chatMessage, client);
            }
          }
          catch (Exception ex) {
            ex.printStackTrace();
          }
	        numMessages ++;

          if (in.hasNextLine()) {
            message = in.nextLine();
          }
          else {
            break;
          }
	   }

     //Determining the session time of a client
     long endTime = System.currentTimeMillis();
     long duration = endTime - startTime;

     //converting milliseconds
     long hours = (duration / 3600000) % 24;
     long minutes = (duration / 60000) % 60;
     long seconds = (duration / 1000) % 60;
     long milisecs = duration % 1000;

     //Formatting session time
     String sessionTime = String.format("%02d::%02d::%02d::%03d", hours, minutes, seconds, milisecs);

      //Send a report back and close the connection
      out.println("Server received " + numMessages + " messages");
      out.println("Session duration: " + sessionTime);
      out.println("DONE");

      try{
         	System.out.println("!!!!! Closing connection... !!!!!" );
            client.close(); 
            synchronized (clientWriters) {
              String byeMessage = username + " has departed";
              chatTextFile.append(byeMessage + "\r\n");
              chatTextFile.flush();
              showMessage(byeMessage, client);
              clientWriters.remove(client);
            }
            connections.remove(client);

            if (connections.isEmpty()) {
              fWriter.close();
              chatTextFile.close();
              fWriter = null;
              chatTextFile = null;
              Files.delete(Paths.get("dln_chat.txt"));
            }
      }
      catch(IOException e){
             System.out.println("Unable to disconnect!");
             System.out.println(e);
             System.exit(1);
      }

  }

  //Private method that displays a message sent by a client
  private void showMessage (String message, Socket sender) {
    synchronized (clientWriters) {
      for (Map.Entry<Socket, PrintWriter> entry : clientWriters.entrySet()) {
        if (entry.getKey() != sender) {
          entry.getValue().println(message);
          entry.getValue().flush();
        }
      }
    }
  }

}
 
