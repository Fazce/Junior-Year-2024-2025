//Programmer: COSC 439/522, Winter '25
//Multi-threaded Client program
//File name: TCPClientMT.java
//When you run this program, you must give both the host name and
//the service port number as command line arguments. For example,
//java TCPClientMT localhost 22222

import java.io.*;
import java.net.*;
import java.util.*;

public class dln_TCPClientMT
{
   private static InetAddress host;
   public static void main(String[] args)
   {
       try {
            // Get server IP-address
                  host = InetAddress.getByName(args[0]);
       }
       catch(UnknownHostException e){
           System.out.println("Host ID not found!");
           System.exit(1);
       }
       run(Integer.parseInt(args[1]));
    }

    private static void run(int port)
    {
        Socket link = null;
        try{
        // Establish a connection to the server
             link = new Socket(host,port); 

        // Set up input and output streams for the connection
            Scanner in = new Scanner(link.getInputStream());
            PrintWriter out = new PrintWriter(link.getOutputStream(),true); 

       //Ask for Client username
            Scanner userEntry = new Scanner(System.in);
            System.out.println("Enter your username: ");
            String username = userEntry.nextLine();
            out.println(username);
                
       // create a sender thread. This thread reads messages typed at the keyboard
       // and sends them to the server
            Sender sender = new Sender(out);

      // start the sender thread
            sender.start();
      
      // main thread continues- it reads messages sent by the server, and displays them on the screen
            String message = "";

      // Get data from the server and display it on the screen
            while (!(message).equalsIgnoreCase("Done")){
               try {
                    message = in.nextLine();
                    System.out.println(message);              
               }
               catch (NoSuchElementException ex){
                    
               }
            }

        }
        catch(IOException e){
             e.printStackTrace();
        }

        finally{
           try{
                 System.out.println("\n!!!!! Closing connection... !!!!!");
                 link.close(); 
            }

           catch(IOException e){
                  System.out.println("Unable to disconnect!");
                  System.exit(1);
           }
        }
    }
}

// The sender class reads messages typed at the keyboard, and sends them to the server
class Sender extends Thread
{
 
    private PrintWriter out;
 
    public Sender (PrintWriter out)
    {

         this.out = out;
    }
       

  // overwrite the method 'run' of the Runnable interface

  // this method is called automatically when a sender thread starts.
 	public void run()
 	{
      //Set up stream for keyboard entry
 		  Scanner userEntry = new Scanner (System.in);
       	  String message;
  
      // Get data from the user and send it to the server
		  do{
		            System.out.print("Enter message: ");
		            message = userEntry.nextLine();
		            out.println(message);
		  }while (!message.equals("DONE"));
   }

}

