README file for dln_proj2

This project was modified to have a multi-threaded chat service between multiple clients

It uses a HashMap of Socket and PrintWriter to connect the clients to each other within the server and allows for the client to see the messages of other clients.

An ArrayList of Socket called "connections" is used to count how many clients are currently connected to the server. If the ArrayList becomes empty, then it means the server is empty. If empty, the chat text file created when the first client connected to the server will be deleted. 

In the Client program, 4 lines of code (40-43) were added, which will prompt the client to enter their username before they enter the server and chat with other clients.

Launch the server program and then run multiple clients. It should work as it worked for me after multiple test attempts.
---------------------------------------------
Explanation for no "nohup.out" file

I ran and tested this on Google Cloud Platform and it worked successfully. However, I could not get the "nohup.out" file to download. Every time I try to download the file, the SSH crashes and I have to restart. After multiple attempts, I could not get the file. 